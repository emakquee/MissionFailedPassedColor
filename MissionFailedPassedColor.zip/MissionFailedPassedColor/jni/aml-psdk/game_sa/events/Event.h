#ifndef __AML_PSDK_SAEVENT_H
#define __AML_PSDK_SAEVENT_H

#include <aml-psdk/game_sa/plugin.h>
#include <aml-psdk/gta_base/Vector.h>

struct CPed;
struct CPedGroup;
struct CEntity;

enum eEventType
{
    EVENT_NONE = 0,
    EVENT_VEHICLE_COLLISION = 1,
    EVENT_PED_COLLISION_WITH_PED = 2,
    EVENT_PED_COLLISION_WITH_PLAYER = 3,
    EVENT_PLAYER_COLLISION_WITH_PED = 4,
    EVENT_OBJECT_COLLISION = 5,
    EVENT_BUILDING_COLLISION = 6,
    EVENT_DRAGGED_OUT_CAR = 7,
    EVENT_KNOCK_OFF_BIKE = 8,
    EVENT_DAMAGE = 9,
    EVENT_DEATH = 10,
    EVENT_DEAD_PED = 11,
    EVENT_POTENTIAL_GET_RUN_OVER = 12,
    EVENT_POTENTIAL_WALK_INTO_PED = 13,
    EVENT_VEHICLE_HIT_AND_RUN = 14,
    EVENT_SHOT_FIRED = 15,
    EVENT_COP_CAR_BEING_STOLEN = 16,
    EVENT_PED_ENTERED_MY_VEHICLE = 17,
    EVENT_REVIVE = 18,
    EVENT_CHAT_PARTNER = 19,
    EVENT_SEXY_PED = 20,
    EVENT_SEXY_VEHICLE = 21,
    EVENT_PED_TO_CHASE = 25,
    EVENT_PED_TO_FLEE = 26,
    EVENT_ATTRACTOR = 27,
    EVENT_VEHICLE_TO_STEAL = 28,
    EVENT_PED_THREAT = 29,
    EVENT_VEHICLE_THREAT = 30,
    EVENT_GUN_AIMED_AT = 31,
    EVENT_SCRIPT_COMMAND = 32,
    EVENT_IN_AIR = 33,
    EVENT_PLAYER_COMMAND = 34,
    EVENT_VEHICLE_DIED = 35,
    EVENT_ACQUAINTANCE_PED_HATE = 36,
    EVENT_ACQUAINTANCE_PED_DISLIKE = 37,
    EVENT_ACQUAINTANCE_PED_LIKE = 38,
    EVENT_ACQUAINTANCE_PED_RESPECT = 39,
    EVENT_ACQUAINTANCE_PED_IGNORE = 40,
    EVENT_VEHICLE_DAMAGE_WEAPON = 41,
    EVENT_SPECIAL = 42,
    EVENT_GOT_KNOCKED_OVER_BY_CAR = 43,
    EVENT_POTENTIAL_WALK_INTO_OBJECT = 44,
    EVENT_CAR_UPSIDE_DOWN = 45,
    EVENT_POTENTIAL_WALK_INTO_FIRE = 46,
    EVENT_GROUP_EVENT = 47,
    EVENT_SCRIPTED_ATTRACTOR = 48,
    EVENT_SHOT_FIRED_WHIZZED_BY = 49,
    EVENT_LOW_ANGER_AT_PLAYER = 50,
    EVENT_HIGH_ANGER_AT_PLAYER = 51,
    EVENT_HEALTH_REALLY_LOW = 52,
    EVENT_HEALTH_LOW = 53,
    EVENT_LEADER_ENTERED_CAR_AS_DRIVER = 54,
    EVENT_LEADER_EXITED_CAR_AS_DRIVER = 55,
    EVENT_POTENTIAL_WALK_INTO_VEHICLE = 56,
    EVENT_LEADER_QUIT_ENTERING_CAR_AS_DRIVER = 57,
    EVENT_ON_FIRE = 58,
    EVENT_FIRE_NEARBY = 59,
    EVENT_POTENTIAL_WALK_INTO_BUILDING = 60,
    EVENT_SOUND_LOUD = 61,
    EVENT_SOUND_QUIET = 62,
    EVENT_ACQUAINTANCE_PED_HATE_BADLY_LIT = 63,
    EVENT_WATER_CANNON = 64,
    EVENT_SEEN_PANICKED_PED = 65,
    EVENT_IN_WATER = 66,
    EVENT_AREA_CODES = 67,
    EVENT_LEADER_FIGHTING = 68,
    EVENT_PLAYER_WANTED_LEVEL = 69,
    EVENT_CREATE_PARTNER_TASK = 70,
    EVENT_PLAYER_COMMAND_TO_GROUP = 71,
    EVENT_SEEN_COP = 72,
    EVENT_VEHICLE_DAMAGE_COLLISION = 73,
    EVENT_ON_ESCALATOR = 74,
    EVENT_DANGER = 75,
    EVENT_PLAYER_COMMAND_TO_GROUP_GATHER = 76,
    EVENT_LEADER_ENTRY_EXIT = 77,
    // GAP
    EVENT_VEHICLE_ON_FIRE = 79,
    EVENT_PHYSICAL_DAMAGE = 80,
    EVENT_INTERIOR_USE_INFO = 81,
    EVENT_INTERIOR_LEAVE = 82,
    // GAP
    EVENT_SIGNAL_AT_PED = 88,
    EVENT_PASS_OBJECT = 89,
    EVENT_NEW_GANG_MEMBER = 90,
    EVENT_WAIT_FOR_PED = 91,
    EVENT_LEAN_ON_VEHICLE = 92,
    EVENT_STUCK_IN_AIR = 93,
    EVENT_DONT_JOIN_GROUP = 94,
    EVENT_PLAYER_CLOSE_BY = 95,
    
    EVENT_TOTAL_NUM_EVENTS = 96
};

DECL_CLASS_VTABLE(CEvent)
    // Construct/Deconstruct functions
    DECL_CTORCALL_PROXY(CEvent, _ZN6CEventC2Ev);
    DECL_DTORCALL_PROXY(CEvent, _ZN6CEventD2Ev);
    DECL_NEWCALL(CEvent, BYBIT(_ZN6CEventnwEj, _ZN6CEventnwEm) );
    DECL_DLCALL(CEvent, _ZN6CEventdlEPv);

    // Virtual functions
    virtual eEventType GetEventType() const;
    virtual int GetEventPriority() const; // TODO: eEventPriorityList
    virtual int GetLifeTime() const;
    virtual CEvent* Clone() const;
    virtual bool AffectsPed(CPed* pPed) const;
    virtual bool AffectsPedGroup(CPedGroup* pPedGroup) const;
    virtual bool IsCriminalEvent() const;
    virtual void ReportCriminalEvent(CPed* pPed) const;
    virtual bool HasEditableResponse() const;
    virtual CEntity* GetSourceEntity() const;
    virtual bool TakesPriorityOver(const CEvent& otherEvent) const;
    virtual float GetLocalSoundLevel() const;
    virtual bool DoInformVehiclreOccupants(CPed* pPed) const;
    virtual bool IsValid(CPed* pPed) const;
    virtual bool CanBeInterruptedBySameEvent() const;

    // STATIC functions
    DECL_FASTCALL_SIMPLE(CalcSoundLevelIncrement, _ZN6CEvent23CalcSoundLevelIncrementEff, float, float fOrig, float fAdd);

    // Member functions
    DECL_THISCALL_HEAD(GetSoundLevel, _ZNK6CEvent13GetSoundLevelEPK7CEntityRK7CVector, float, CEntity const* pSourceEnt, CVector const& vecMicPos)
    DECL_THISCALL_TAIL(GetSoundLevel, pSourceEnt, vecMicPos)

    // Member values
    int m_iAccumulatedTime;
    bool m_bIsPersistent;
DECL_CLASS_END()

#endif // __AML_PSDK_SAEVENT_H
