LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE        := MissionFailedColor64
LOCAL_CPP_EXTENSION := .cpp
LOCAL_SRC_FILES     := main.cpp mod/logger.cpp mod/config.cpp
LOCAL_C_INCLUDES    := $(LOCAL_PATH)
LOCAL_CXXFLAGS      += -O2 -DNDEBUG -std=c++17 -fvisibility=hidden
LOCAL_LDLIBS        += -llog
include $(BUILD_SHARED_LIBRARY)
